OPTICAL AND FUSION RANDOM FOREST FEATURE IMPORTANCE

Input files:
- sar_features.csv
- s2_features.csv
- master_table.csv
- folds.csv

Method:
- Matched all 1,206 fields by field_id.
- Used the existing five spatial folds from folds.csv.
- Trained one RandomForestClassifier per fold, using the other four folds for training.
- Model settings match the project's saved task2_3_sar.py model definition:
  n_estimators=400, class_weight='balanced', random_state=0, n_jobs=-1.
- Missing feature values were imputed using the median of the training fold only.
- Reported feature importance is the mean across the five fold-trained models.
- The error bars in the graphs show standard deviation across folds.

Important:
These are feature importances regenerated from the original feature tables and the same spatial-fold setup. They are not taken from a previously saved .pkl model.
The SAR/Optical contribution is calculated by summing the mean fused-model feature importances for each feature group.

Computed modality contribution:
SAR: 62.86%
Optical: 37.14%

The fold-average scores printed in the associated CSVs are descriptive fold averages and may differ slightly from pooled out-of-fold scores in the Week 6 report.
